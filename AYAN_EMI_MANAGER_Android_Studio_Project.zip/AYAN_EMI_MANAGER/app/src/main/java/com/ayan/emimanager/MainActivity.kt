package com.ayan.emimanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class Customer(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val phone: String,
    val model: String,
    val imei: String,
    val price: Long,
    val downPayment: Long,
    val months: Int,
    val paid: Long = 0L,
    val firstDueDate: String
) {
    val totalDue: Long get() = (price - downPayment - paid).coerceAtLeast(0)
    val monthlyInstallment: Long get() =
        if (months > 0) kotlin.math.ceil((price - downPayment).coerceAtLeast(0).toDouble() / months).toLong() else 0
}

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("ayan_emi", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFF075985),
                secondary = androidx.compose.ui.graphics.Color(0xFF0F766E)
            )) {
                var customers by remember { mutableStateOf(loadCustomers()) }
                var showForm by remember { mutableStateOf(false) }
                var paymentFor by remember { mutableStateOf<Customer?>(null) }

                fun persist(updated: List<Customer>) {
                    customers = updated
                    saveCustomers(updated)
                }

                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("AYAN EMI MANAGER", fontWeight = FontWeight.Bold) },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = androidx.compose.ui.graphics.Color.White
                            )
                        )
                    },
                    floatingActionButton = {
                        FloatingActionButton(onClick = { showForm = true }) {
                            Text("+")
                        }
                    }
                ) { padding ->
                    Column(
                        Modifier.padding(padding).fillMaxSize().padding(16.dp)
                    ) {
                        SummaryCard(customers)
                        Spacer(Modifier.height(12.dp))
                        Text("ক্রেতার তালিকা", style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if (customers.isEmpty()) {
                            Text("এখনো কোনো ক্রেতা যোগ করা হয়নি। নিচের + বাটনে চাপ দিন।")
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(customers, key = { it.id }) { customer ->
                                    CustomerCard(
                                        customer = customer,
                                        onPayment = { paymentFor = customer },
                                        onDelete = {
                                            persist(customers.filterNot { it.id == customer.id })
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                if (showForm) {
                    AddCustomerDialog(
                        onDismiss = { showForm = false },
                        onSave = { customer ->
                            persist(customers + customer)
                            showForm = false
                        }
                    )
                }

                paymentFor?.let { customer ->
                    PaymentDialog(
                        customer = customer,
                        onDismiss = { paymentFor = null },
                        onSave = { amount ->
                            val updated = customers.map {
                                if (it.id == customer.id)
                                    it.copy(paid = (it.paid + amount).coerceAtMost(it.price - it.downPayment))
                                else it
                            }
                            persist(updated)
                            paymentFor = null
                        }
                    )
                }
            }
        }
    }

    private fun loadCustomers(): List<Customer> {
        return try {
            val raw = prefs.getString("customers", "[]") ?: "[]"
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Customer(
                    id = o.optLong("id"),
                    name = o.optString("name"),
                    phone = o.optString("phone"),
                    model = o.optString("model"),
                    imei = o.optString("imei"),
                    price = o.optLong("price"),
                    downPayment = o.optLong("downPayment"),
                    months = o.optInt("months"),
                    paid = o.optLong("paid"),
                    firstDueDate = o.optString("firstDueDate")
                )
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveCustomers(customers: List<Customer>) {
        val arr = JSONArray()
        customers.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id); put("name", c.name); put("phone", c.phone)
                put("model", c.model); put("imei", c.imei); put("price", c.price)
                put("downPayment", c.downPayment); put("months", c.months)
                put("paid", c.paid); put("firstDueDate", c.firstDueDate)
            })
        }
        prefs.edit().putString("customers", arr.toString()).apply()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SummaryCard(customers: List<Customer>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("হিসাবের সারাংশ", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("মোট ক্রেতা: ${customers.size}")
            Text("মোট বকেয়া: ৳${customers.sumOf { it.totalDue }}")
            Text("মোট জমা: ৳${customers.sumOf { it.downPayment + it.paid }}")
        }
    }
}

@Composable
private fun CustomerCard(
    customer: Customer,
    onPayment: () -> Unit,
    onDelete: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(customer.name, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)
            Text("ফোন: ${customer.phone}")
            Text("মডেল: ${customer.model}")
            if (customer.imei.isNotBlank()) Text("IMEI: ${customer.imei}")
            Text("মোট দাম: ৳${customer.price} | ডাউন পেমেন্ট: ৳${customer.downPayment}")
            Text("মেয়াদ: ${customer.months} মাস | মাসিক কিস্তি: ৳${customer.monthlyInstallment}")
            Text("প্রথম কিস্তির তারিখ: ${customer.firstDueDate}")
            Text("জমা: ৳${customer.downPayment + customer.paid}")
            Text(
                "বকেয়া: ৳${customer.totalDue}",
                color = if (customer.totalDue > 0) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPayment, enabled = customer.totalDue > 0) {
                    Text("কিস্তি জমা")
                }
                OutlinedButton(onClick = onDelete) { Text("মুছুন") }
            }
        }
    }
}

@Composable
private fun AddCustomerDialog(
    onDismiss: () -> Unit,
    onSave: (Customer) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var imei by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var down by remember { mutableStateOf("0") }
    var months by remember { mutableStateOf("6") }
    var date by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন ক্রেতা যোগ করুন") },
        text = {
            Column(Modifier.heightIn(max = 560.dp)) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    item { FormField("ক্রেতার নাম", name, { name = it }) }
                    item { FormField("মোবাইল নম্বর", phone, { phone = it }, KeyboardType.Phone) }
                    item { FormField("ফোনের মডেল", model, { model = it }) }
                    item { FormField("IMEI (ঐচ্ছিক)", imei, { imei = it }) }
                    item { FormField("ফোনের দাম (টাকা)", price, { price = it }, KeyboardType.Number) }
                    item { FormField("ডাউন পেমেন্ট (টাকা)", down, { down = it }, KeyboardType.Number) }
                    item { FormField("কিস্তির মেয়াদ (মাস)", months, { months = it }, KeyboardType.Number) }
                    item { FormField("প্রথম কিস্তির তারিখ (YYYY-MM-DD)", date, { date = it }) }
                    if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val p = price.toLongOrNull()
                val d = down.toLongOrNull()
                val m = months.toIntOrNull()
                error = when {
                    name.isBlank() || phone.isBlank() || model.isBlank() -> "নাম, নম্বর ও মডেল দিন।"
                    p == null || p <= 0 -> "ফোনের সঠিক দাম দিন।"
                    d == null || d < 0 || d > p -> "ডাউন পেমেন্ট সঠিক নয়।"
                    m == null || m <= 0 -> "কিস্তির মেয়াদ সঠিক নয়।"
                    date.isBlank() -> "প্রথম কিস্তির তারিখ দিন।"
                    else -> ""
                }
                if (error.isBlank()) onSave(
                    Customer(
                        name = name.trim(), phone = phone.trim(), model = model.trim(),
                        imei = imei.trim(), price = p!!, downPayment = d!!, months = m!!,
                        firstDueDate = date.trim()
                    )
                )
            }) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun FormField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PaymentDialog(
    customer: Customer,
    onDismiss: () -> Unit,
    onSave: (Long) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("কিস্তি জমা নিন") },
        text = {
            Column {
                Text("${customer.name} — বকেয়া ৳${customer.totalDue}")
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("জমার পরিমাণ (টাকা)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(onClick = {
                val a = amount.toLongOrNull()
                error = if (a == null || a <= 0 || a > customer.totalDue)
                    "সঠিক টাকার পরিমাণ দিন।" else ""
                if (error.isBlank()) onSave(a!!)
            }) { Text("জমা নিশ্চিত করুন") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
