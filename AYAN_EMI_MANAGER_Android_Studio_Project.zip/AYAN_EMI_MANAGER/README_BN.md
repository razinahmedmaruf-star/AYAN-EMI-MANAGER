# AYAN EMI MANAGER — Android Studio starter project

এই প্রজেক্টটি একটি প্রাথমিক Android অ্যাপের সোর্স কোড। এতে আছে:
- ক্রেতা যোগ করা
- ফোনের মডেল ও ঐচ্ছিক IMEI সংরক্ষণ
- ফোনের দাম, ডাউন পেমেন্ট, কিস্তির মেয়াদ ও প্রথম কিস্তির তারিখ
- কিস্তির টাকা জমা এবং বকেয়া হিসাব
- সারাংশ ও ক্রেতা মুছে ফেলার সুবিধা

## Android Studio-তে চালানোর নিয়ম
1. ZIP ফাইলটি Extract করুন।
2. Android Studio খুলে `AYAN_EMI_MANAGER` ফোল্ডারটি Open করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Android ফোনে Developer options ও USB debugging চালু করে USB দিয়ে যুক্ত করুন, অথবা Emulator চালু করুন।
5. Run ▶ চাপুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই সংস্করণে তথ্য শুধু ওই ফোনের private app storage-এ থাকে। এটি এখনো online server/Firebase sync করে না।
- অ্যাপ uninstall করলে বা app data clear করলে তথ্য হারাতে পারে। বাস্তব গ্রাহকের তথ্য ব্যবহারের আগে নিরাপদ ব্যাকআপ, authentication, server-side access rules এবং privacy notice যোগ করতে হবে।
- এই প্রজেক্টে APK build করা হয়নি; Android Studio দিয়ে build করতে হবে।
- এটি Android Enterprise/device-lock feature বাস্তবায়ন করে না। বৈধ device management-এর জন্য উপযুক্ত Android Enterprise provider/EMM, device enrollment, supported-device verification, explicit customer disclosure/consent, এবং আলাদা server-side integration দরকার। সাধারণ APK দিয়ে ইচ্ছেমতো অন্য ফোন লক করা যায় না।
- IMEI সংবেদনশীল ডিভাইস-তথ্য। প্রয়োজন না হলে সংগ্রহ করবেন না; সংগ্রহ করলে সীমিত অ্যাক্সেস ও নিরাপদ সংরক্ষণ ব্যবহার করুন।

## পরবর্তী উৎপাদন-প্রস্তুত ধাপ
1. Firebase Authentication বা অন্য নিরাপদ login
2. Firestore/নিজস্ব API এবং server-side security rules
3. নির্ভরযোগ্য কিস্তির due-date scheduler ও push notifications
4. Payment receipt/history, audit log, backup/export
5. Android Enterprise/EMM provider-এর সামঞ্জস্য যাচাই ও integration
